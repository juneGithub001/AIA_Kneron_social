Copy the app binaries (*.bin) in ota/ready_to_load

age_gender:           support age_gender applications (ISI/DME)
object_detection:     support object_detection_8_class applications (ISI/DME)
pedestrian_detection: support pedestrian_detection applications (ISI/DME)
ssd_fd:               support ssd_fd applications (ISI/DME)
tiny_yolo_v3:         support tiny_yolo_v3 applications (ISI/DME) and other DME applications