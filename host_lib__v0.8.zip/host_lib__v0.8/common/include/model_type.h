#ifndef __MODEL_TYPE_H
#define __MODEL_TYPE_H

// Uncomment this Macro for customer2
//#define CUSTOMER2

enum model_type {
    INVALID_ID,
    KNERON_FDSMALLBOX                   = 1,
    KNERON_FDANCHOR                     = 2,
    KNERON_FDSSD                        = 3,
    AVERAGE_POOLING                     = 4,
    KNERON_LM_5PTS                      = 5,
    KNERON_LM_68PTS                     = 6,
    KNERON_LM_150PTS                    = 7,
    KNERON_FR_RES50                     = 8,
    KNERON_FR_RES34                     = 9,
    KNERON_FR_VGG10                     = 10,
    KNERON_TINY_YOLO_PERSON             = 11,
    KNERON_3D_LIVENESS                  = 12,
    KNERON_GESTURE_RETINANET            = 13,
    TINY_YOLO_VOC                       = 14,
    IMAGENET_CLASSIFICATION_RES50       = 15,
    IMAGENET_CLASSIFICATION_RES34       = 16,
    IMAGENET_CLASSIFICATION_INCEPTION_V3= 17,
    IMAGENET_CLASSIFICATION_MOBILENET_V2= 18,
    TINY_YOLO_V3                        = 19,
    KNERON_2D_LIVENESS                  = 20,
    KNERON_FD_RETINANET                 = 21,
    KNERON_SSD_PERSON                   = 22,
    KNERON_AGE_GENDER                   = 23,
    KNERON_NIR_LIVENESS                 = 24,

    KNERON_OD_MBSSD                     = 27,
    KNERON_PD_MBSSD                     = 28,
    KNERON_FR_MASK                      = 29,
    USER_MODEL_0                        = 100, // for customer2
    USER_MODEL_1                        = 101, // for customer2
    USER_MODEL_2                        = 102, // for customer2
    //USER_MODEL_3                        = 103,
    //USER_MODEL_4                        = 104,
};

#endif
