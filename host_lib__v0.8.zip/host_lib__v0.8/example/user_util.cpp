/**
 * @file      user_util.cpp
 * @brief     kdp host lib user test examples 
 * @version   0.1 - 2019-07-31
 * @copyright (c) 2019 Kneron Inc. All right reserved.
 */

#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"

#include <string.h>
#include <unistd.h>
#include <sys/time.h>

#if defined (__cplusplus) || defined (c_plusplus)
extern "C"{
#endif



int read_file_to_buf(char* buf, const char* fn, int nlen) {
    if (buf == NULL || fn == NULL) {
        printf("file name or buffer is null!\n");
        return -1;
    }

    FILE* in = fopen(fn, "rb");
    if (!in) {
        printf("opening file %s failed, error:%s.!\n", fn, strerror(errno));
        return -1;
    }

    fseek(in, 0, SEEK_END);
    long f_n = ftell(in);  //get the size
    if (f_n > nlen) {
        printf("buffer is not enough.!\n");
        fclose(in);
        return -1;
    }

    fseek(in, 0, SEEK_SET);  //move to begining

    int res = 0;
    while (1) {
        int len = fread(buf + res, 1, 1024, in);
        if (len == 0) {
            if (!feof(in)) {
                printf("reading from img file failed:%s.!\n", fn);
                fclose(in);
                return -1;
            }
            break;
        }
        res += len;  //calc size
    }
    fclose(in);
    return res;
}

double what_time_is_it_now() {
    struct timeval time;
    if (gettimeofday(&time, NULL)) {
        return 0;
    }
    return (double)time.tv_sec + (double)time.tv_usec * .000001;
}

struct kdp_dme_cfg_s create_dme_cfg_struct() {
    struct kdp_dme_cfg_s dme_cfg;
    memset(&dme_cfg, 0, sizeof(kdp_dme_cfg_s));
    return dme_cfg;
}

struct kdp_isi_cfg_s create_isi_cfg_struct() {
    struct kdp_isi_cfg_s isi_cfg;
    memset(&isi_cfg, 0, sizeof(kdp_isi_cfg_s));
    return isi_cfg;
}

#if defined (__cplusplus) || defined (c_plusplus)
}
#endif
