/**
 * @file      user_util.h
 * @brief     kdp host lib user test header file
 * @version   0.1 - 2019-08-01 
 * @copyright (c) 2019 Kneron Inc.All right reserved.
 */

#ifndef __USER_UTIL__H__
#define __USER_UTIL__H__

#if defined (__cplusplus) || defined (c_plusplus)
extern "C"{
#endif

#define TEST_DIR                      HOST_LIB_DIR "/test_images"
#define TEST_IMG_DIR                  TEST_DIR "/img/"
#define TEST_DME_DIR                  TEST_DIR "/dme/"
#define TEST_DME_YOLO_3MODELS_DIR     TEST_DIR "/dme_yolo_3models/"
#define TEST_DME_YOLO_DIR             TEST_DIR "/dme_yolo/"
#define TEST_DME_MOBILENET_DIR        TEST_DIR "/dme_mobilenet/"
#define TEST_AgeGender_DIR            TEST_DIR "/age_gender/"
#define TEST_DME_OD_DIR               TEST_DIR "/dme_od_8class/"
#define TEST_DME_SSD_FD_DIR           TEST_DIR "/dme_ssd_fd/"
#define TEST_DME_YOLO_224_DIR         TEST_DIR "/dme_yolo_224/"

#define TEST_OTA_DIR                  HOST_LIB_DIR "/app_binaries/ota/"

#define IMAGE_DATA_FILE (TEST_IMG_DIR "u1_f1_rgb.bin")
#define IMAGE_DATA_FILE_2 (TEST_IMG_DIR "u16_f1_rgb.bin")

#define IMAGE_SIZE (640*480*2)
#define SLEEP_TIME 1000

int read_file_to_buf(char* buf, const char* fn, int nlen);
double what_time_is_it_now();
struct kdp_dme_cfg_s create_dme_cfg_struct();
struct kdp_isi_cfg_s create_isi_cfg_struct();
#if defined (__cplusplus) || defined (c_plusplus)
}
#endif

#endif
