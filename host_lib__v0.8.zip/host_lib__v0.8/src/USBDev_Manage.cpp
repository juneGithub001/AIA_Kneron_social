#include "KnLog.h"
#include "USBDev_Manage.h"
#include "MsgMgmt.h"

#include <libusb-1.0/libusb.h>

extern MsgMgmt*    _p_mgr;

//struct user_usb_devices_info user_devices_table[MAX_COM_DEV];

void kdp_get_user_devices_path(libusb_device *dev, uint8_t* port_numbers, uint8_t * usb_bus)
{
     *usb_bus= libusb_get_bus_number(dev);
     *port_numbers=  libusb_get_port_number(dev);
}

int32_t kdp_get_user_devices_name(libusb_device_handle* device_h,uint8_t desc_index, unsigned char *name_buffer,uint8_t name_len)
{
     int32_t ret = 0;
    if ( (ret = libusb_get_string_descriptor_ascii(device_h, desc_index, name_buffer, name_len) )< 0) {

            KnPrint(KN_LOG_ERR, "usb device get name[%d] error \n",desc_index);
            ret = -1;
    }
    return ret;
}

int32_t kdp_get_user_devices_serial_number( libusb_device_handle* device_h,uint8_t iserialnumber_usb, unsigned char *serial_number,uint8_t serial_len)
{
   return kdp_get_user_devices_name(device_h, iserialnumber_usb, serial_number, serial_len);
}

int32_t kdp_get_user_devices_product_name( libusb_device_handle* device_h,uint8_t iproduct_usb,uint8_t *product, uint8_t product_len)
{
   
    return kdp_get_user_devices_name(device_h, iproduct_usb, product, product_len) ;
}

int32_t kdp_get_user_devices_Manufacturer_name( libusb_device_handle* device_h,uint8_t iproduct_usb,uint8_t *Manufacturer, uint8_t Manufacturer_len)
{
   
    return kdp_get_user_devices_name(device_h, iproduct_usb, Manufacturer, Manufacturer_len) ;
}

void kdp_get_user_devices_name_handle(libusb_device_handle *device_h,struct user_usb_devices_info * dev_info)
{
    if(dev_info->user_device_iSerialNumber !=0)
    {
        kdp_get_user_devices_serial_number(device_h,dev_info->user_device_iSerialNumber,dev_info->SerialNumber, 33);    
        
        KnPrint(KN_LOG_DBG,"dev[%d] serial number is %s\n", dev_info->dev_idx,dev_info->SerialNumber);
    }

    if(dev_info->user_device_iProduct !=0)
    {
        kdp_get_user_devices_product_name(device_h,dev_info->user_device_iProduct,dev_info->Product_name, 33);  
    }

    if(dev_info->user_device_iManufacturer !=0)
    {
        kdp_get_user_devices_product_name(device_h,dev_info->user_device_iManufacturer,dev_info->Manufacturer_name, 33);  
    }
}

void kdp_usb_devices_table_clear(struct user_usb_devices_info * tab, int tab_num)
{
       for(int i = 0; i < tab_num; i++)
       {
        (tab+i)->user_device = NULL;
        (tab+i)->puser_device = NULL;
        (tab+i)->user_device_iManufacturer = 0;
        (tab+i)->user_device_iProduct = 0;
        (tab+i)->user_device_iSerialNumber = 0;
        (tab+i)->user_device_status = STA_DISCONNECTED;

        (tab+i)->bus_num = 0;
        (tab+i)->port_num = 0;
        (tab+i)->dev_idx = -1;

        memset((tab+i)->SerialNumber, 0, 33);
        memset((tab+i)->Product_name, 0, 33);
        memset((tab+i)->Manufacturer_name, 0, 33);
                
       }
       
}

int kdp_usb_devices_table_swap(struct user_usb_devices_info * src, struct user_usb_devices_info * dst)
{
    struct user_usb_devices_info temp ;
    int len = sizeof(struct user_usb_devices_info);
    
    if((src == NULL) || (dst == NULL))
    {
        return -1;
    }

    memset((void *)&temp, 0 , len);

    memcpy((void *)&temp, src, len);
    memcpy(src, dst, len);
    memcpy(dst, &temp, len);

    return 0;

}

USBDEV_Mgmt::USBDEV_Mgmt()
{
    kdp_usb_devices_table_clear(user_devices_table, MAX_COM_DEV); 
    memset(user_usb_thread_id, 0, MAX_COM_DEV*sizeof(pthread_t));
}

USBDEV_Mgmt::~USBDEV_Mgmt()
{
     for(int i = 0; i < MAX_COM_DEV; i++)
     {
        if( (user_devices_table+i)->user_device != NULL)
        {
            delete( (user_devices_table+i)->user_device);
        }
    }
    kdp_usb_devices_table_clear(user_devices_table, MAX_COM_DEV); 
}

int USBDEV_Mgmt::kdp_discovery_usb_dev(struct user_usb_devices_info *usb_dev_info, int* dev_cnt)
{
    libusb_device ** devs;
    libusb_device *dev;

    struct libusb_device_descriptor desc;
    libusb_device_handle *dev_handle = NULL;

    struct user_usb_devices_info usb_dev_tmp[MAX_COM_DEV];

    int i = 0;
    int dev_num = 0;
    int rv = -1;

    kdp_usb_devices_table_clear(usb_dev_tmp, MAX_COM_DEV); 
    
    ssize_t cnt = libusb_get_device_list(NULL, &devs);
    if(cnt < 0) {
        KnPrint(KN_LOG_ERR, "get usb device list failed, error code:%d.\n", cnt);
        return (int) cnt;
    }
    
    // get current devices information, status: STA_attached
    while( (dev = devs[i++]) != NULL) 
    {
       
        rv = libusb_get_device_descriptor(dev, &desc);
        if(rv != 0) {
            KnPrint(KN_LOG_ERR, "get usb device descriptor failed, error code:%d.\n", rv);
            continue;
        }

        if(desc.idProduct == PRODUCT_ID && desc.idVendor == VENDOR_ID) {
            KnPrint(KN_LOG_DBG, "found correct usb dev vid:%d, pid:%d,%d.\n", 
                VENDOR_ID, PRODUCT_ID, desc.iSerialNumber);

            /*add device information*/
            (usb_dev_tmp+dev_num)->user_device_status = STA_ATTACHED;
            
            kdp_get_user_devices_path(dev, &(usb_dev_tmp+dev_num)->port_num, &(usb_dev_tmp+dev_num)->bus_num);
            if(desc.iSerialNumber != 0)
            {
                (usb_dev_tmp+dev_num)->user_device_iSerialNumber = desc.iSerialNumber;
                (usb_dev_tmp+dev_num)->user_device_iManufacturer = desc.iManufacturer;
                (usb_dev_tmp+dev_num)->user_device_iProduct      = desc.iProduct;

                /*query if information already exists in the devices struct array*/
                int status = libusb_open(dev, &dev_handle);
                if( status != 0 || !dev_handle ) {
                    KnPrint(KN_LOG_ERR, "discovery usb device vid:%d, pid:%d, open failed: [%s].\n",VENDOR_ID, PRODUCT_ID, libusb_error_name(status));
                    //return status;
                }
                else
                {
                    kdp_get_user_devices_name_handle(dev_handle, (usb_dev_tmp+dev_num));
                    libusb_close(dev_handle);
                    
                }
            }
            (usb_dev_tmp+dev_num)->puser_device = dev;
            dev_num ++;
            if(dev_num > (MAX_COM_DEV+1))
            {
                rv = -10; //Special return value
                KnPrint(KN_LOG_ERR, "Too many devices were found, exceed the maximum number of devices.\n");
                break;
            }
            //break; 
        }
    }

    *dev_cnt = dev_num;
    user_usb_devices_num = dev_num;

    bool exist_flag = false;
    uint8_t old_cnt = 0;
    int j = 0;
    int tmp_cnt = 0;
    /*detect the existence of old devices */
    for(old_cnt = 0;old_cnt < MAX_COM_DEV;old_cnt++)
    { 
        //compare serial number
        if((usb_dev_info+old_cnt)->user_device_status >= STA_DISCOVERED)
        {
            for(j = tmp_cnt;j<dev_num; j++)
            {
                if((usb_dev_info+old_cnt)->user_device_iSerialNumber > 0) // serial number ≠ 0 
                {
                    if(strcmp((char *)(usb_dev_info+old_cnt)->SerialNumber,(char *)(usb_dev_tmp+j)->SerialNumber)== 0)
                    {
                        exist_flag = true;
                        break;
                    }
                }
                else // serial number ==0
                {
                    if(((usb_dev_info+old_cnt)->bus_num == (usb_dev_tmp+j)->bus_num ) &&
                        ((usb_dev_info+old_cnt)->port_num == (usb_dev_tmp+j)->port_num )  )
                    {
                        exist_flag = true;
                        break;
                    }
                }
            }

            if(exist_flag)
            {
                exist_flag = false;
                (usb_dev_tmp+j)->user_device_status = STA_DISCOVERED;
                tmp_cnt= old_cnt ;
                if((usb_dev_tmp+j)->puser_device != NULL)
                {
                    (usb_dev_info+old_cnt)->puser_device =  (usb_dev_tmp+j)->puser_device;
                }
            }
            else
            {
                if((usb_dev_info+old_cnt)->user_device != NULL)
                {
                    (usb_dev_info+old_cnt)->puser_device = NULL;
                }
                else
                {
                    kdp_usb_devices_table_clear(usb_dev_info+old_cnt,1);
                }
                
            }
        }

    }

    /*judge whether there is new device*/
    for(old_cnt =0 ;old_cnt< dev_num; old_cnt++)
    {
        if( (usb_dev_tmp+old_cnt)->user_device_status == STA_ATTACHED)
        {
            for(j = 0; j < MAX_COM_DEV; j++)
            {
                if((usb_dev_info+j)->user_device_status == STA_DISCONNECTED)
                {
                    (usb_dev_tmp+old_cnt)->user_device_status = STA_DISCOVERED;
                    memcpy((usb_dev_info+j), (usb_dev_tmp+old_cnt), sizeof(struct user_usb_devices_info ));
                    break;
                }
            }
        }
    }

    return rv;
}

int USBDEV_Mgmt::kdp_add_all_usb_devs(int* dev_idxs, int* dev_cnt)
{
    int ret = -1;
    int cnt = 0;
   // int dev_idx = 0;

    ret = kdp_discovery_usb_dev(user_devices_table, dev_cnt);
    
    if(dev_cnt <= 0)
    {
        KnPrint(KN_LOG_ERR,"Discovery devices error. please check your devices!\n");
        return -1;
    }

   
    while(cnt < *dev_cnt)
    {
        ret = kdp_add_usb_dev((user_devices_table+cnt), &dev_idxs[cnt], true);
        cnt++;
    } 

    return ret;

}


int USBDEV_Mgmt::kdp_add_usb_dev(struct user_usb_devices_info* sts, int *dev_idx, bool auto_flag)
{
    int ret = 0;

    if(sts->user_device_status != STA_DISCOVERED)
    {
         KnPrint(KN_LOG_DBG, "adding usb dev [status error]:%d\n ",sts->user_device_status);
         return -1;
    }

     /*claim devices and config the interface */
    sts->user_device = new USBDev(VENDOR_ID, PRODUCT_ID);
    KnPrint(KN_LOG_DBG, "created usb dev %x,%x.\n", VENDOR_ID, PRODUCT_ID);

    KnPrint(KN_LOG_DBG, "trying to init usb port..\n");
    if(sts->user_device->u_init_port(sts->puser_device) < 0) {
        KnPrint(KN_LOG_ERR, "USB dev init port failed.\n");
        delete sts->user_device;
        //kdp_usb_devices_table_clear((user_devices_table+cnt));
        return -2;
    } 
    else {
        KnPrint(KN_LOG_DBG, "trying to open usb device..\n");
        if(sts->user_device->u_open() < 0) {
            KnPrint(KN_LOG_ERR, "USB dev name open failed.\n");
            delete sts->user_device;
            //kdp_usb_devices_table_clear((user_devices_table+cnt));
            return -3;
        }
    }

     /*add device*/
    KnPrint(KN_LOG_DBG, "adding usb dev ...\n");
    if(!auto_flag)
    {
        ret = _p_mgr->add_usb_device(sts->user_device,*dev_idx);
    }
    else
    {
        ret = _p_mgr->add_usb_device(sts->user_device);
    }
    
    if(ret < 0) 
    {
        delete sts->user_device;
        // kdp_usb_devices_table_clear((user_devices_table+cnt));
        return -4;
    }
    
    if(auto_flag)
    {
        *dev_idx = ret; 
    }
    sts->dev_idx = ret;
    sts->user_device_status = STA_CONNECTED;    
    
    /* get information */
    if(sts->user_device_iSerialNumber > 0)
    {
        memcpy(sts->user_device->serialnumber,sts->SerialNumber, 33);
    }
   
    kdp_get_user_devices_path(sts->puser_device,&sts->user_device->usb_port,&sts->user_device->usb_bus);
    KnPrint(KN_LOG_DBG, "adding usb dev usb path[%d:%d]...\n",sts->user_device->usb_bus,sts->user_device->usb_port);

    user_usb_thread_id[*dev_idx]  = _p_mgr->start_receiver(*dev_idx);
    
    return 0;
}

int USBDEV_Mgmt::kdp_get_devs_num()
{
    return user_usb_devices_num;
}

int USBDEV_Mgmt::kdp_query_all_usb_devs(struct user_usb_devices_info* sts, int* dev_cnt)
{   
   if(sts == NULL)
   {
       KnPrint(KN_LOG_DBG, "Query devices's status parameter error \n");
       return -1;
   }
    
   *dev_cnt = kdp_get_devs_num();
  
   memcpy(sts, user_devices_table, *dev_cnt * (sizeof(struct user_usb_devices_info)));

   return 0;
   
}

int USBDEV_Mgmt::kdp_query_usb_dev(struct user_usb_devices_info* sts, int dev_idx)
{
    int ret = -1;
    if(dev_idx <0 || (dev_idx >= MAX_COM_DEV))
    {
        KnPrint(KN_LOG_DBG, "Query specified device's status parameter error \n");
        return -2;
    }
    for(int i = 0;i < MAX_COM_DEV; i++)
    {
        if((user_devices_table+i)->dev_idx == dev_idx)
        {
            memcpy(sts, user_devices_table+dev_idx, sizeof(struct user_usb_devices_info));
            ret = 0;
            break;
        }
    }
    
    return ret;
}

int USBDEV_Mgmt::kdp_remove_usb_dev(int dev_idx)
{
    int ret = -1;
    if(dev_idx <0 || (dev_idx >= MAX_COM_DEV))
    {
        KnPrint(KN_LOG_DBG, "Remove specified device's status parameter error \n");
        return -2;
    }

    for(int i = 0;i < MAX_COM_DEV; i++)
    {
        if((user_devices_table+dev_idx)->dev_idx == dev_idx)
        {
             _p_mgr->rm_usb_device((user_devices_table+dev_idx)->user_device, dev_idx);
            if( (user_devices_table+dev_idx)->user_device != NULL)
            {
                delete( (user_devices_table+dev_idx)->user_device);
            }
            kdp_usb_devices_table_clear(user_devices_table+dev_idx,1);
           
            ret = 0;
            if(user_usb_devices_num > 0)
                user_usb_devices_num-=1;
            
            pthread_cancel(user_usb_thread_id[dev_idx]);
            break;
        }
    }
    
    return ret;
}

void USBDEV_Mgmt::kdp_remove_all_usb_dev()
{
    for(int i = 0;i < MAX_COM_DEV; i++)
    {
        _p_mgr->rm_usb_device((user_devices_table+i)->user_device);
        if( (user_devices_table+i)->user_device != NULL)
        {
            delete( (user_devices_table+i)->user_device);
        }
        if(user_devices_table->dev_idx > 0)
        {
            pthread_cancel(user_usb_thread_id[user_devices_table->dev_idx]);
        }
    }
    kdp_usb_devices_table_clear(user_devices_table,MAX_COM_DEV);

    user_usb_devices_num = 0;
}

int USBDEV_Mgmt::kdp_reconnect_usb_dev(int dev_idx)
{
   // struct user_usb_devices_info* dev_tmp = NULL;
    int dev_cnt = 0;

    kdp_discovery_usb_dev(user_devices_table, &dev_cnt);
    if(dev_cnt > 0)
    {
        if(user_devices_table[dev_idx].puser_device != NULL)
        //if(user_devices_table[dev_idx].user_device_status == STA_CONNECTED && (user_devices_table[dev_idx].user_device != NULL))
        {
            KnPrint(KN_LOG_DBG, "trying to init usb port..\n");
            if(user_devices_table[dev_idx].user_device->u_init_port(user_devices_table[dev_idx].puser_device) < 0) {
                KnPrint(KN_LOG_ERR, "USB dev init port failed.\n");
                //if(user_devices_table[dev_idx].user_device != NULL)
                //    delete user_devices_table[dev_idx].user_device;
                //kdp_usb_devices_table_clear((user_devices_table+cnt));
                return -2;
            } 
            else {
                KnPrint(KN_LOG_DBG, "trying to open usb device..\n");
                if(user_devices_table[dev_idx].user_device->u_open() < 0) {
                    KnPrint(KN_LOG_ERR, "USB dev name open failed.\n");
                    //if(user_devices_table[dev_idx].user_device != NULL)
                    //    delete user_devices_table[dev_idx].user_device;
                    //kdp_usb_devices_table_clear((user_devices_table+cnt));
                    return -3;
                }
            }
        }
        else
        {
            KnPrint(KN_LOG_ERR, "The status of the devices to which the index is incorrect..\n");
            return -4;
        }
    }
    else
    {   
        KnPrint(KN_LOG_ERR, "Dont find any devices..\n");
        return -1;
    }

    return 0;
}
