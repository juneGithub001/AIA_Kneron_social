/**
 * @file      kdp_host.h
 * @brief     kdp host lib header file
 * @version   0.1 - 2019-04-19
 * @copyright (c) 2019 Kneron Inc. All right reserved.
 */

#ifndef __KDP_HOST__H__
#define __KDP_HOST__H__

#if defined (__cplusplus) || defined (c_plusplus)
extern "C"{
#endif

#define KDP_UART_DEV   0
#define KDP_USB_DEV    1

#define IMG_FORMAT_RGBA8888     0x80000000
#define IMG_FORMAT_RAW8         0x80000020

/* The data byte sequence in DDR memory is [lowest byte]Y0CbY1CrY2CbY3Cr...[highest byte] */
#define IMG_FORMAT_YCbCr422     0x80000037
#define IMG_FORMAT_RGB565       0x80000060

#define DEF_FR_THRESH        FID_THRESHOLD
#define DEF_RGB_FR_THRESH    DEF_FR_THRESH
#define DEF_NIR_FR_THRESH    DEF_FR_THRESH

#include <stdint.h>
#include <stdio.h>
#include "common.h"
#include "ipc.h"

// dme image configuration structure
struct kdp_dme_cfg_s {
    int32_t     model_id;
    int32_t     output_num;
    int32_t     image_col;        // column size. NIR8: must be multiple of 4; RGB565/YCBCR422: must be multiple of 2.
    int32_t     image_row;        // row size
    int32_t     image_ch;         // channel size
    uint32_t    image_format;     // image format

    /* Image processing parameters */
    struct kdp_crop_box_s   crop_box;                   // y1, y2, x1, x2, for future use
    struct kdp_pad_value_s  pad_values;                 // for future use
    float                   ext_param[MAX_PARAMS_LEN];  // extra parameters, such as threshold
};

// isi image configuration structure
struct kdp_isi_cfg_s {
    uint32_t     app_id;           // application id
    uint32_t     res_buf_size;     // result buffer size
    uint16_t     image_col;        // column size. NIR8: must be multiple of 4; RGB565/YCBCR422: must be multiple of 2.
    uint16_t     image_row;        // row size
    uint32_t     image_format;     // image format

    /* Image processing parameters */
    struct kdp_crop_box_s   crop_box;                   // y1, y2, x1, x2, for future use
    struct kdp_pad_value_s  pad_values;                 // for future use
    float                   ext_param[MAX_PARAMS_LEN];  // extra parameters, such as threshold
};

//-----------------------library init ----------------------

/**
 * init the host library
 * return 0 on succeed, -1 on failure
 */
int kdp_lib_init();

/**
 * start the host library to wait for messages
 * return 0 on succeed, -1 on failure
 */
int kdp_lib_start(); //kdp lib start

/**
 * free the resources used by host lib
 * return 0 on succeed, -1 on failure
 */
int kdp_lib_de_init(); //kdp lib de init

/**
 * init the host lib internal log
 * dir: the directory name of the log file
 * name: the log file name
 * return 0 on succeed, -1 on failure
 */
int kdp_init_log(const char* dir, const char* name); //init log

/**
 * add com device to the host lib
 * type: the device type, only KDP_UART_DEV supported now
 * name: the UART device name
 * return dev idx on succeed, -1 on failure
 */
int kdp_add_dev(int type, const char* name); //add device to communicate
//---------------------- lib init end------------------------


//-----------------------system operation APIs --------------------------
/**
 * request for doing system reset
 * dev_idx: connected device ID. A host can connect several devices
 * reset_mode: specifies the reset mode

 *             0 - no operation
               1 - reset message protocol
               3 - switch to suspend mode
               4 - switch to active mode
               255 - reset whole system
               256 - system shutdown(RTC)
               0x1000xxxx - reset debug output level

 * return value: 0 on succeed, else for error code
 */
int kdp_reset_sys(int dev_idx, uint32_t reset_mode);

/**
 * request for system status
 * dev_idx: connected device ID. A host can connect several devices
 * device: the name of the device
 * sfw_id: the id of the scpu firmware in device
 * sbuild_id: the build number of the scpu firmware in device
 * sys_status: system status
 * app_status: application status
 * nfw_id: the id of the ncpu firmware in device
 * nbuild_id: the build number of the ncpu firmware in device
 * return value: 0 on succeed, else -1
 */
int kdp_report_sys_status(int dev_idx, uint32_t* sfw_id, uint32_t* sbuild_id,
                          uint16_t* sys_status, uint16_t* app_status, uint32_t* nfw_id, uint32_t* nbuild_id);

/**
 * request for system KN number
 * dev_idx: connected device ID. A host can connect several devices
 * kn_num: the pointer to store KN number
 * return value: 0 on succeed, else -1
 */
int kdp_get_kn_number(int dev_idx, uint32_t *kn_num);

/**
 * request for model IDs in DDR or Flash
 * dev_idx: connected device ID. A host can connect several devices
 * from_ddr: if models are in ddr (1) or flash (0)
 * data_buf: the pointer to store model info
 * return value: 0 on succeed, else -1
 */
int kdp_get_model_info(int dev_idx, int from_ddr, char *data_buf);

/**
 * request for update firmware
 * dev_idx: connected device ID. A host can connect several devices
 * module_id: the module id of which the firmware to be updated
              0 - no operation
              1 - scpu module
              2 - ncpu module
 * img_buf, buf_len: the fw image buffer and file size
 * return value: 0 if succeed, else error code
 */
int kdp_update_fw(int dev_idx, uint32_t* module_id, char* img_buf, int buf_len);

/**
 * request for update model
 * dev_idx: connected device ID. A host can connect several devices
 * model_id: the model id to be updated, reserved for future use
 * model_size: the size of the model
 * img_buf, buf_len: the fw image buffer and file size
 * return value: 0 if succeed, else error code
 */
int kdp_update_model(int dev_idx, uint32_t* model_id, uint32_t model_size,
                     char* img_buf, int buf_len);

/**
 * request for update spl
 * dev_idx: connected device ID. A host can connect several devices
 * mode: the command mode to be exercised
 * auth_type, auth_key: the authenticator type and key
 * spl_buf and size: the spl fw image and file size
 * spl_id: the id of the spl firmware in device (post command execution)
 * spl_build: the build number of the spl firmware in device
 * return value: 0 if succeed, else error code
 */
int kdp_update_spl(int dev_idx, uint32_t mode, uint16_t auth_type, uint16_t spl_size,
     uint8_t* auth_key, char* spl_buf, uint32_t* rsp_code, uint32_t* spl_id, uint32_t* spl_build);

//-----------------------system operation APIs end--------------------------

//-----------------------app level APIs--------------------------

/**
 * start the user sfid mode with specified threshold, image format
 * dev_idx: connected device ID. A host can connect several devices
 * img_size: the required image file size will be returned.
 * thresh:  the threshold used to match face recognition result.
            if 0, the default threshold is used.
 * img_width: the width of input image, MUST be multiple of 2 for RGB565/YCBCR422
 * img_height: the height of input image
 * format: the input image format
 * return 0 on succeed, error code on failure
 */
int kdp_start_sfid_mode(int dev_idx, uint32_t* img_size, float thresh,
                        uint16_t width, uint16_t height, uint32_t format);

/**
 * extract the face feature from input image, and compare it with DB,
 * return the matched user ID, and face analysis related result.
 * dev_idx: connected device ID. A host can connect several devices
 * user_id: matched user ID in DB will be returned.
 * img_buf, buf_len: the image buffer and file size
 * mask: indicate the requested and responsed flags
 * bit 0 - FD result
 * bit 1 - LM data
 * bit 2 - FM feature map
 * bit 3 - liveness
 * res: contains all the related result
 * FD/LM/FR/LV result size: please refer to model_res.h
 * return 0 on succeed, error code on failure
 */
int kdp_verify_user_id_generic(int dev_idx, uint16_t* user_id, char* img_buf, int buf_len,
                               uint16_t* mask, char* res);


/**
 * start the user register mode
 * dev_idx: connected device ID. A host can connect several devices
 * user_id: the user id that will be registered.
 * img_idx: the image idx that will be saved. (a user could have 5 images)
 * return 0 on succeed, -1 else
 */
int kdp_start_reg_user_mode(int dev_idx, uint16_t usr_id, uint16_t img_idx);

/**
 * @brief get lw3D result mask
 * @return mask
 */
uint16_t kdp_get_res_mask(bool fd, bool lm, bool fr, bool liveness);

/**
 * @brief get result size
 * @return result size
 */
uint32_t kdp_get_res_size(bool fd, bool lm, bool fr, bool liveness);

/**
 * extract face feature from inut image and save it in device,
 * returns face detection, face recoginition result.
 * dev_idx: connected device ID. A host can connect several devices
 * img_buf, buf_len: the image buffer and file size
 * mask: indicate the requested and responsed flags
   bit 0 - FD result
   bit 1 - LM data
   bit 2 - FM feature map
   bit 3 - liveness
 * res: contains all the related result
 * FD/LM/FR/LV result size: please refer to model_res.h
 * return 0 on succeed, error code on failure
 */
int kdp_extract_feature_generic(int dev_idx, char* img_buf, int buf_len, uint16_t* mask, char* res);

/**
 * register the face features to device DB
 * dev_idx: connected device ID. A host can connect several devices
 * user_id: the user id that be registered. must be same as the kdp_start_reg_user_mode.
 * before calling this API, host must have called kdp_extract_feature
 * at least once successfully, otherwise, no features could be saved.
 * return 0 on succeed, error code on failure
 */
int kdp_register_user(int dev_idx, uint32_t user_id);

/**
 * remove user from device DB
 * It needs to be called after start lw3d mode or start verify mode
 * dev_idx: connected device ID. A host can connect several devices
 * user_id: the user to be removed. 0 for all users
 * return 0 on succeed, error code on failure
 */
int kdp_remove_user(int dev_idx, uint32_t user_id);

/**
 * start the light weight 3D mode  with specified threshold, img format
 * dev_idx: connected device ID. A host can connect several devices
 * rgb_size: the required rgb image file size will be returned.
 * nir_size: the required nir image file size will be returned.
 * rgb_thresh:  the threshold used to match rgb face recognition result.
            if 0, the default threshold is used.
 * nir_thresh:  the threshold used to match nir face recognition result.
            if 0, the default threshold is used.
 * rgb_width: the width of rgb image, MUST be multiple of 2
 * rgb_height: the height of rgb image
 * nir_width: the width of nir image, MUST be multiple of 4
 * nir_height: the height of nir image
 * rgb_fmt:   the format of rgb image
 * nir_fmt:  the format of nir image
 * return 0 on succeed, error code on failure
 */
int kdp_start_lw3d_mode(int dev_idx, uint32_t* rgb_size, uint32_t* nir_size,
                        float rgb_thresh, float nir_thresh, uint16_t rgb_width, uint16_t rgb_height,
                        uint16_t nir_width, uint16_t nir_height, uint32_t rgb_fmt, uint32_t nir_fmt);

/**
 * @brief get lw3D result mask
 * @return mask
 */
uint16_t kdp_get_lw3D_res_mask(bool fd, bool lm, bool fr, bool nir_fd, bool nir_lm, bool nir_fr, bool liveness);

/**
 * @brief get lw3D result size
 * @return result size
 */
uint32_t kdp_get_lw3D_res_size(bool fd, bool lm, bool fr, bool nir_fd, bool nir_lm, bool nir_fr, bool liveness);

/**
 * extract the face feature from input rgb/nir image, and save it in device,
 * return the face analysis related result if required.
 * dev_idx: connected device ID. A host can connect several devices
 * img_buf, buf_len: the rgb image buffer and file size
 * img_buf_nir, buf_len_nir: the nir image buffer and file size

 * mask: indicate the requested and responsed flags
   bit 0 - FD result
   bit 1 - FM feature map
   bit 2 - LM data
   bit 4 - NIR FD result
   bit 5 - NIR feature map
   bit 6 - NIR LM data
   bit 8 - Final liveness
 * res: contains all the related result
 * FD/LM/FR/LV result size: please refer to model_res.h
 * return 0 on succeed, error code on failure
 */
int kdp_extract_lw3D_feature_generic(int dev_idx, char* img_buf, int buf_len,
                                     char* img_buf_nir, int buf_len_nir, uint16_t* mask, char* res);

/**
 * extract the face feature from input rgb/nir image, and compare it with DB,
 * return the matched user ID, and face analysis related result.
 * dev_idx: connected device ID. A host can connect several devices
 * user_id: matched user ID in DB will be returned.
 * img_buf, buf_len: the rgb image buffer and file size
 * img_buf_nir, buf_len_nir: the nir image buffer and file size

 * mask: indicate the requested and responsed flags
   bit 0 - FD result
   bit 1 - FM feature map
   bit 2 - LM data
   bit 4 - NIR FD result
   bit 5 - NIR feature map
   bit 6 - NIR LM data
   bit 8 - Final liveness
 * res: contains all the related result
 * FD/LM/FR/LV result size: please refer to model_res.h
 * return 0 on succeed, error code on failure
 */
int kdp_verify_lw3D_image_generic(int dev_idx, uint16_t* user_id, char* img_buf,
     int buf_len, char* img_buf_nir, int buf_len_nir, uint16_t* mask, char* res);

/**
 * @brief Calculate similarity of two feature points
 * @param user_fm_a buffer A of user feature map data
 * @param user_fm_b buffer B of user feature map data
 * @param fm_size   size of user feature map data
 * @return similarity score,smaller score are more similar
 *         errcode -1:parameter error
 * @note  user must ensure buffer A and B are the same size
 */
float kdp_fm_compare(float *user_fm_a, float *user_fm_b, size_t fm_size);

//-----------------------app level APIs end-------------------------------------

//-----------------------image streaming interface APIs --------------------------
/**
 * start the user isi mode with specified app id and return data size
 * dev_idx: connected device ID. A host can connect several devices
 * buf_size: the depth of the image buffer will be returned.
 * img_width: the width of input image
 * img_height: the height of input image
 * format: the input image format
 * return 0 on succeed, error code on failure
 */
int kdp_start_isi_mode(int dev_idx, uint32_t app_id, uint32_t return_size, uint16_t width, uint16_t height, uint32_t format, uint32_t* rsp_code, uint32_t* buf_size);

/**
 * start the user isi mode with isi configuration and return buffer size
 * dev_idx: connected device ID. A host can connect several devices
 * isi_cfg: isi configuration data
 * cfg_size: isi configuration data size
 * rsp_code: response code from device
 * buf_size: the depth of the image buffer will be returned.
 * return 0 on succeed, error code on failure
 */
int kdp_start_isi_mode_ext(int dev_idx, char* isi_cfg, int cfg_size, uint32_t* rsp_code, uint32_t* buf_size);

/**
 * start an inference with an image
 * dev_idx: connected device ID. A host can connect several devices
 * img_buf, buf_len: the image buffer and file size
 * img_id: the sequence id of the image
 * img_buf_available: the number of image buffer still available for input
 * before calling this API, host must call kdp_start_isi to configure the isi application.
 * return 0 on succeed, error code on failure
 */
int kdp_isi_inference(int dev_idx, char* img_buf, int buf_len, uint32_t img_id,
                       uint32_t* rsp_code, uint32_t* img_buf_available);

/**
 * request for getting an inference results
 * dev_idx: connected device ID. A host can connect several devices
 * img_id: sequence id to get inference results of an image with the specified id
 * inf_size: inference data size
 * inf_res: inference result data
 * return 0 on succeed, error code on failure
 */
int kdp_isi_retrieve_res(int dev_idx, uint32_t img_id, uint32_t* rsp_code,
                          uint32_t* r_size, char* r_data);

//-----------------------image streaming interface APIs end --------------------------

//-----------------------dynamic model execution APIs --------------------------
/**
 * request for starting dynamic model execution
 * dev_idx: connected device ID. A host can connect several devices
 * model_size: size of inference model
 * data: firmware setup data
 * dat_size: setup data size
 * ret_size: returned model size
 * img_buf, buf_len: the model file buffer and file size
 * return 0 on succeed, error code on failure
 */
int kdp_start_dme(int dev_idx, uint32_t model_size, char* data, int dat_size,
                  uint32_t* ret_size, char* img_buf, int buf_len);

/**
 * request for configuring dme
 * dev_idx: connected device ID. A host can connect several devices
 * data: inference setup data
 * dat_size: the size of setup data
 * ret_model_id: the return value of model id for this configuration
 * return 0 on succeed, error code on failure
 */
int kdp_dme_configure(int dev_idx, char* data, int dat_size, uint32_t* ret_model_id);

/**
 * calling KL520 to do inference with provided model
 * dev_idx: connected device ID. A host can connect several devices
 * img_buf, buf_len: the image buffer and file size
 * inf_size: the size of inference result in DME serial mode; the session id of the image in DME async mode
 * res_flag: indicate whether result is requested and available
 * inf_res: contains the returned inference result
 * model: running mode: normal or async mode 
 * model_id: the model id for this configuration
 * before calling this API, host must call kdp_start_dme and kdp_dme_configure to configure the dme model.
 * return 0 on succeed, error code on failure
 */
int kdp_dme_inference(int dev_idx, char* img_buf, int buf_len, uint32_t* inf_size,
                      bool* res_flag, char* inf_res, uint16_t mode, uint16_t model_id);

/**
 * request for retrieving dme result
 * dev_idx: connected device ID. A host can connect several devices
 * addr: the ddr address to retrieve
 * len: the size of data to retrieve
 * inf_res: contains the retrieving result
 * return 0 on succeed, error code on failure
 */
int kdp_dme_retrieve_res(int dev_idx, uint32_t addr, int len, char* inf_res);

/**
 * request for getting dme inference status
 * dev_idx: connected device ID. A host can connect several devices
 * ssid: ssid to get inference status
 * status: inference status, 0 for not ready, 1 for ready
 * inf_size: inference data size
 * inf_res: inference result data
 * return 0 on succeed, error code on failure
 */
int kdp_dme_get_status(int dev_idx, uint16_t *ssid, uint16_t *status, uint32_t* inf_size, char* inf_res);

/**
 * request for ending dme mode
 * dev_idx: connected device ID. A host can connect several devices
 * return value: 0 on succeed, else for error code
 */
int kdp_end_dme(int dev_idx);

//-----------------------dynamic model execution APIs end --------------------------

#if defined (__cplusplus) || defined (c_plusplus)
}
#endif

#endif
