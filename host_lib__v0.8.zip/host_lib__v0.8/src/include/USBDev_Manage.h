/**
 * @file      USBDev_Manage.h
 * @brief     Header file for USB Dev manage class
 * @version   0.1 - 2020-08-20
 * @copyright (c) 2020 Kneron Inc. All right reserved.
 */

#ifndef __USB_DEV_MANAGE_H__
#define __USB_DEV_MANAGE_H__

#include <libusb-1.0/libusb.h>

#include "KdpHostApi.h"
#include "USBDev.h"
/***
 *    ---> STA_DISCONNECTED(initial status) ------> STA_DISCOVERED -------> STA_CONNECTED ----|
 *    |                                                                                       |
 *    |----------------------------------------------------------------------------------------  
 * ***/
typedef enum {
  STA_DISCONNECTED = 0, //default status disconnected
  STA_ATTACHED,        // host probed the devices but not add into user usb devices manage list
  STA_DISCOVERED,     // add devices into user devices manage list  but not open
  STA_CONNECTED ,    // connect the usb device
}eusb_devices_status;


struct user_usb_devices_info{
    USBDev *user_device ;
    libusb_device * puser_device;

    /** Index of string descriptor describing manufacturer */
    uint8_t  user_device_iManufacturer;

    /** Index of string descriptor describing product */
    uint8_t  user_device_iProduct;

    /** Index of string descriptor containing device serial number */
    uint8_t  user_device_iSerialNumber;

    /** string descriptor describing manufacturer, max length 128*/
    unsigned char Manufacturer_name[33];

    /** string descriptor describing product*/
    unsigned char Product_name[33];

    /** string descriptor containing device serial number */
    unsigned char SerialNumber[33];

    /* usb device bus number */
    uint8_t bus_num ;

    /* usb device port number */
    uint8_t port_num;

    /** usb device's status ,default value is 0(disconnected)*/
    eusb_devices_status user_device_status;

    /** the devices index*/
    uint8_t dev_idx;



};

class USBDEV_Mgmt {
public:
    /** \desc
         * Add all USB dev to host lib, host lib auto assign index
         * host lib will auto detect all USB devices and assign index, 
         * the user uses the device directly according to the index number in the array
         * 
         * \param[OUT] dev_idxs the pointer of the usb index array
         * \param[OUT] dev_cnt  the count of the USB devices number
         * \returns 
     *       0 on success, 
     *       or error code on failure
     * \note  If some of the devices in multiple devices failed, the devices will be ignored
     *        and other devices will be added
    */ 
    int kdp_add_all_usb_devs(int* dev_idxs, int* dev_cnt);

    /** \desc
         * Add a USB dev with user-specified index to host lib
         * user can specify the index number to be added into host lib after 
         * get the devices information . If the index is occupied, the user must 
         * first call kdp_remove_usb_dev() to release the source.
         *
         * \param[IN] usb_dev_info     the information of the user's USB device
         * \param[IN/OUT] dev_idx      if auto flag set ture, dev_idx as a output parameter, will auto assign device index
         *                             if auto flag set false, dev_idx as a input parameter, device will be added based on 
         *                             a user-specified index.
         * \param[IN] auto_flag        refer to the dev_idx parameter
         * \returns 0 on success, or error code on failure
    */
    int kdp_add_usb_dev(struct user_usb_devices_info* usb_dev_info, int *dev_idx, bool auto_flag);

    /** \desc
         * Query ALL USB dev status
         * user can get the status information of the cuurently connected USB devices by
         * calling the API. host lib not re-detected the USB devices.
         *
         * \param[OUT] usb_dev_info     the information of the user's USB device
         * \param[OUT] dev_cnt          the count of the USB devices number
         * \returns 0 on success, or error code on failure
    */
    int kdp_query_all_usb_devs(struct user_usb_devices_info* usb_dev_info, int* dev_cnt);

    /** \desc
         * Query specified USB dev status
         * user can get the status information of the currently connected USB devices 
         * through the index.
         *
         * \param[OUT] usb_dev_info     the information of the user's USB device
         * \param[IN] dev_idx           the index of the USB devices number
         * \returns      0 on success, 
         *               -1 USB devices dont exist 
         *               -2 parameter error
    */
    int kdp_query_usb_dev(struct user_usb_devices_info* usb_dev_info, int dev_idx);

    /** \desc
         * Remove specified USB dev status
         * host lib will clear the device's status information of the index, the index
         * will not be available until it is reallocated.
         *
         * \param[IN] dev_idx the index of the USB devices number
         * \returns 0 on success, 
         *          -1 USB devices dont exist 
         *          -2 parameter error 
    */
    int kdp_remove_usb_dev(int dev_idx);

    /** \desc
        * Remove all USB dev status
        * host lib will clear all the status information of the currently connected USB devices.
        *
        * 
    */
    void kdp_remove_all_usb_dev();

    /** \desc
         * Discovery all USB dev
         * host lib will detect all USB devices and refersh the array of
         * USB devices status, user can call kdp_add_usb_dev to add devices
         * based on the array.
         *
         * \param[OUT] usb_dev_info    the pointer to an array of user_usb_devices_info
         * \param[IN] dev_cnt the count of the USB devices number
         * \returns 
     *        0 on success, 
     *        -10 indicates that the number of devices found exceeds the set maximum
     *        error code on failure
     *           
    */
    int kdp_discovery_usb_dev(struct user_usb_devices_info* usb_dev_info, int* dev_cnt);

    /** \desc
         * Reconnect specified USB dev
         * host lib will connect according to the saved of the information of USB devices and  this API is only available for 
     * had connected USB devices.
         * If USB dev is in error or disconnected, its status is "STA_DISCONNECTED".
         * To bring it in service, call this API after plug in.
         * \param[IN] dev_idx the index of the USB devices number
         * \returns 0 on success, or error code on failure
    */
    int kdp_reconnect_usb_dev(int dev_idx);

    USBDEV_Mgmt();
    virtual ~USBDEV_Mgmt();

    int kdp_get_devs_num();

    private:
          user_usb_devices_info user_devices_table[MAX_COM_DEV];
          uint8_t user_usb_devices_num ;

          pthread_t user_usb_thread_id[MAX_COM_DEV];

};




#endif