How to set configuration in DME mode

Please refer to utils/dme/README.txt for more details