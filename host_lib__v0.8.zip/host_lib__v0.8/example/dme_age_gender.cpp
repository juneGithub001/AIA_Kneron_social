/**
 * @file      user_test_age_gender.cpp
 * @brief     kdp host lib user test examples 
 * @version   0.1 - 2019-11-26
 * @copyright (c) 2019 Kneron Inc. All right reserved.
 */

#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"

#include <string.h>
#include <unistd.h>
#include "user_util.h"
#include "ipc.h"
#include "base.h"
#include "model_res.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#define DME_IMAGE_FILE      (TEST_AgeGender_DIR "image_rgb565.bin")
#define DME_MODEL_FILE      (TEST_AgeGender_DIR "all_models.bin")
#define DME_FW_SETUP        (TEST_AgeGender_DIR "fw_info.bin")

#define DME_IMG_SIZE (640 * 480 * 2)
#define DME_MODEL_SIZE (20 * 1024 * 1024)
#define DME_FWINFO_SIZE 128

#define FACE_SCORE_THRESHOLD  0.8f
int user_test_age_gender(int dev_idx, int user_id, int mode, struct kdp_dme_cfg_s dme_cfg)
{
    uint32_t ret_model_id = 0;

    if (1) {
        uint32_t model_size = 0;
        char data[DME_FWINFO_SIZE];
        int dat_size = 0;
        char* p_buf = NULL;
        uint32_t buf_len = 0;
        uint32_t ret_size = 0;

        //read firmware setup data
        memset(data, 0, sizeof(data));
        int n_len = read_file_to_buf(data, DME_FW_SETUP, DME_FWINFO_SIZE);
        if (n_len <= 0) {
            printf("reading fw setup file failed:%d...\n", n_len);
            return -1;
        }
        dat_size = n_len;

        p_buf = new char[DME_MODEL_SIZE];
        memset(p_buf, 0, DME_MODEL_SIZE);
        n_len = read_file_to_buf(p_buf, DME_MODEL_FILE, DME_MODEL_SIZE);
        if (n_len <= 0) {
            printf("reading model file failed:%d...\n", n_len);
            delete[] p_buf;
            return -1;
        }
        buf_len = n_len;
        model_size = n_len;

        printf("starting DME inference in [serial mode] ...\n");
        int ret = kdp_start_dme(
            dev_idx, model_size, data, dat_size, &ret_size, p_buf, buf_len);
        if (ret != 0) {
            printf("could not set to DME mode:%d..\n", ret_size);
            delete[] p_buf;
            return -1;
        }

        delete[] p_buf;
        printf("DME mode succeeded...\n");
        usleep(SLEEP_TIME);
    }

    if (1) {
        int dat_size = 0;

        dat_size = sizeof(struct kdp_dme_cfg_s);
        printf("starting DME configure ...\n");
        int ret = kdp_dme_configure(dev_idx, (char *)&dme_cfg, dat_size, &ret_model_id);
        if (ret != 0) {
            printf("could not set to DME configure mode..\n");
            return -1;
        }
        printf("DME configure model[%d] succeeded...\n", ret_model_id);
        usleep(SLEEP_TIME);
    }

    if (1) {
        uint32_t inf_size = 0;
        fd_age_gender_res inf_res;
        bool res_flag = true;

        char img_buf[DME_IMG_SIZE];
        uint32_t buf_len = 0;

        // TODO need set image name here
        memset(img_buf, 0, sizeof(img_buf));
        int n_len = read_file_to_buf(img_buf, DME_IMAGE_FILE, DME_IMG_SIZE);
        if (n_len <= 0) {
            printf("reading dme image file failed:%d...\n", n_len);
            return -1;
        }

        buf_len = n_len;

        printf("starting DME inference ...\n");
        int ret = kdp_dme_inference(dev_idx, img_buf, buf_len, &inf_size, &res_flag, (char*) &inf_res, 0, 0);
        if (ret != 0) {
            printf("could not set to DME inference mode..\n");
            return -1;
        }

        kdp_dme_retrieve_res(dev_idx, 0, inf_size, (char*) &inf_res);

        if (inf_res.fd_res.score > FACE_SCORE_THRESHOLD) {
            printf("[INFO] FACE DETECT (x1, y1, x2, y2, score) = %f, %f, %f, %f, %f\n", \
                    inf_res.fd_res.x1, inf_res.fd_res.y1, \
                    inf_res.fd_res.x2, inf_res.fd_res.y2, \
                    inf_res.fd_res.score);
            if (0 == inf_res.ag_res.age && 0 == inf_res.ag_res.ismale) {
                printf("[INFO] FACE TOO SMALL\n");
            } else {
                printf("[INFO] AGE_GENDER (Age, Gender) = %d, %s\n", \
                       inf_res.ag_res.age, \
                       inf_res.ag_res.ismale ? "Male" : "Female");
            }

        }
        else {
            printf("[INFO] NO FACE OR FACE SCORE TOO LOW!!!\n");
        }

        printf("DME inference succeeded...\n");
        kdp_end_dme(dev_idx);
        usleep(SLEEP_TIME);
    }
    return 0;
}



int user_test(int dev_idx, int user_id)
{
    struct kdp_dme_cfg_s dme_cfg = create_dme_cfg_struct();
    // dme configuration
    dme_cfg.model_id     = 3;   // the first model id when compiling in toolchain
    dme_cfg.output_num   = 1;   // number of output node for the last model
    dme_cfg.image_col    = 640;
    dme_cfg.image_row    = 480;
    dme_cfg.image_ch     = 3;
    dme_cfg.image_format = IMAGE_FORMAT_SUB128 | IMAGE_FORMAT_MODEL_AGE_GENDER | NPU_FORMAT_RGB565;

    // Serial mode (0)
    uint16_t mode = 0;

    //dme test
    user_test_age_gender(dev_idx, user_id, mode, dme_cfg);

    return 0;
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
