/**
 * @file      USBDev.h
 * @brief     Header file for USB Dev class
 * @version   0.1 - 2019-04-28
 * @copyright (c) 2019 Kneron Inc. All right reserved.
 */

#ifndef __USB_DEV_H__
#define __USB_DEV_H__

#include <libusb-1.0/libusb.h>

#include "BaseDev.h"

#define VENDOR_ID   0x3231
#define PRODUCT_ID  0x0100

#define EP_IN_INT       0x81
#define EP_IN_BULK      0x81

#define EP_OUT_INT      0x02
#define EP_OUT_BULK     0x02

#define ACK_PACKET_SIZE 16
#define USB_MAX_BYTES   (4 << 20)

#define USB_FAKE_FD_START 0x1000

using namespace std;

class USBDev : public BaseDev {
public:
    USBDev(int vid, int pid);
    virtual ~USBDev();

    int u_open();
    int u_init_port();
    int u_init_port(struct libusb_device* device);

    int u_get_device_list();
    struct libusb_device* u_find_macth_dev(struct libusb_device** dev_list, uint8_t* serial_number);

    virtual int send(int8_t* msgbuf, int msglen);
    virtual int receive(int8_t* msgbuf, int msglen);

    int recv_data_ack();
    int send_data_ack(uint32_t action, uint32_t src_id, uint32_t len);
    int send_image_data(char *buf, int data_len);
    int send(char* msgbuf, int msglen);
    int receive(char* msgbuf, int msglen);

    int receive_bulk(char* msgbuf, int msglen);
    int send_bulk(char* msgbuf, int msglen, bool send_zero_byte);
    int check_to_send_zero_byte(size_t len, unsigned char endpoint);
    int check_to_receive_zero_byte(size_t len, unsigned char endpoint);

    int usb_recv(int8_t* msgbuf, int msglen);
    int reconnect_usb();
    virtual void shutdown_dev();
    virtual void restart_dev();

    libusb_device_handle*    m_pkneron_device_h;
    uint8_t serialnumber[33];
    uint8_t usb_port;
    uint8_t usb_bus;
private:
    
    struct libusb_device*    p_kneron_dev;
    struct libusb_device**   p_dev_list;

    int vendor_id;
    int product_id;

    static int _inst_cnt;
};

#endif
