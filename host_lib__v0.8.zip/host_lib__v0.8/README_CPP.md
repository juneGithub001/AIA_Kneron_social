# Kneron Host Lib

This project contains C++ examples for using Kneron edge devices

This is a brief introduction. For more detailed documents, please visit <http://doc.kneron.com/docs>.

## Environment Requirements
### Linux
- install libusb
    `sudo apt install libusb-1.0-0-dev`
### Windows(MINGW64/MSYS)
- environment, gcc, etc.
    - get [git for windows SDK (MUST BE!)](https://gitforwindows.org/) installed
- install libusb
    `pacman -S mingw-w64-x86_64-libusb`
- install cmake
    `pacman --needed -S mingw-w64-x86_64-cmake`
    > make sure you are using `/mingw64/bin/cmake`
- install opencv_3.4
    - get [opencv_3.4.1, mingw-w64-x86_64-opencv-3.4.1-1-any.pkg.tar.xz](https://repo.msys2.org/mingw/x86_64/) installed:
    `pacman -U mingw-w64-x86_64-opencv-3.4.1-1-any.pkg.tar.xz`
    > make sure you enter the directory of opencv xz file in msys command line

## Build
### Linux
```bash
mkdir build && cd build
 # to build opencv_3.4 example: cmake -DBUILD_OPENCV_EX=on ..
cmake ..
make -j4
```

### Windows(MINGW64/MSYS)
```bash
 # to build opencv_3.4 example: cmake -DBUILD_OPENCV_EX=on .. -G"MSYS Makefiles"
mkdir build && cd build
cmake .. -G"MSYS Makefiles"
make -j4
```

## Output Bin Files
``host_lib/build/bin/*``
 
## USB Device Permissions

### Linux
Add the following to /etc/udev/rules.d/10-local.rules
```
KERNEL=="ttyUSB*",ATTRS{idVendor}=="067b",ATTRS{idProduct}=="2303",MODE="0777",SYMLINK+="kneron_uart"
KERNEL=="ttyUSB*",ATTRS{idVendor}=="1a86",ATTRS{idProduct}=="7523",MODE="0777",SYMLINK+="kneron_pwr"
SUBSYSTEM=="usb",ATTRS{idVendor}=="3231",ATTRS{idProduct}=="0100",MODE="0666"
```
