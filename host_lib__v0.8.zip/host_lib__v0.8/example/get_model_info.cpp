/**
 * @file      get_model_info.cpp
 * @brief     kdp host lib user example
 * @version   0.1 - 2020-09-01
 * @copyright (c) 2020 Kneron Inc. All right reserved.
 */

#include "kdp_host.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

static int user_test_get_model_info(int dev_idx, int user_id)
{
    int ret;
    char model_info[1024]; // total_number(4 bytes) + model_id_1(4 bytes) + model_id_2(4 bytes) + ...
    uint32_t *p_model_info;

    if (1 == user_id) {
        printf("starting get model info in DDR\n");
    } else {
        printf("starting get model info in Flash\n");
    }

    // 0 - Flash, 1 - DDR
    ret = kdp_get_model_info(dev_idx, user_id, model_info);
    if (ret != 0) {
        printf("Could not get model IDs\n");
        return -1;
    }

    p_model_info = (uint32_t *)model_info;
    if (p_model_info[0] == 0xFFFF) {
        printf("Not supported by the version of the firmware\n");
    } else {
        printf("Total model: %d\n", p_model_info[0]);
        for (uint32_t k = 0; k < p_model_info[0]; k++) {
            printf("Model %d: ID %d\n", k, p_model_info[1+k]);
        }
    }
    
    return 0;
}

int user_test(int dev_idx, int user_id)
{
    user_test_get_model_info(dev_idx, user_id);

    return 0;
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
