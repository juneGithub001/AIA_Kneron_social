/**
 * Copyright (C) 2020 Kneron Inc. All right reserved
 *
 * @file kapp_id.h
 * @brief Kneron Application Shared Data
 */

#ifndef __KAPP_ID_H__
#define __KAPP_ID_H__

enum APP_ID {
    APP_UNKNOWN = 0,
    APP_LW3D,
    APP_SFID,
    APP_DME,
    APP_AGE_GENDER,
    APP_OD,
    APP_TINY_YOLO3,
    APP_FD_LM,
    APP_PD,
    APP_ID_MAX
};

#endif // __KAPP_ID_H__
