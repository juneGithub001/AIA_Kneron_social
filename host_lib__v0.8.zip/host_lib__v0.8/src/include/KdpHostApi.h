/**
 * @file      KdpHostApi.h
 * @brief     kdp host api header file
 * @version   0.1 - 2019-04-18
 * @copyright (c) 2019 Kneron Inc. All right reserved.
 */

#ifndef __KDP_HOST_API_H__
#define __KDP_HOST_API_H__

#define MAX_COM_DEV    3

#include "kdp_host.h"
#include "kdp_host_async.h"


#if !defined(THREAD_USE_CPP11)

#include "pthread.h"
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <errno.h>


class mutex   
{  
public:  
    
  explicit mutex(bool processShared = false) :  
    _processShared(processShared)  
  {  
    pthread_mutexattr_t attr;  
    memset(&attr, 0, sizeof(pthread_mutexattr_t));
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_NORMAL);  
  
    if (processShared) {  
        int shared;  
        pthread_mutexattr_getpshared(&attr, &shared);  
        //assert(shared ==  PTHREAD_PROCESS_PRIVATE);  
        pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);  
    }  
     
    int err = pthread_mutex_init(&_mutex, &attr);  
    (void) err;  
  }  
  
  ~mutex()  
  {  
    int err = pthread_mutex_destroy(&_mutex);  
    (void) err;  
  }  
  
  int lock()  
  {  
    return pthread_mutex_lock(&_mutex);  
  }  
  
  int unlock()  
  {  
    return pthread_mutex_unlock(&_mutex);  
  }  
  
  pthread_mutex_t* getmutexPtr()  
  {  
    return &_mutex;  
  }  
  
private:  
  pthread_mutex_t _mutex;  
  bool _processShared;  
  //mutex(const mutex&) ;  //= delete
  //mutex& operator=(const mutex&) ;  //= delete
};

/*mutexLockGuard holds this_mutex; 
  uses constructors and destructors in C++ to apply for and release a mutex
*/
class mutexLockGuard   
{  
public:  
  mutexLockGuard(const mutexLockGuard&) ;  //= delete
  mutexLockGuard& operator=(const mutexLockGuard&) ;  //= delete
  
  explicit mutexLockGuard(mutex& mutex) :  
   _mutex(mutex)  
  {  
    _mutex.lock();  
  }  
  
  ~mutexLockGuard()  
  {  
    _mutex.unlock();  
  }  
  
private:  
  mutex& _mutex;  
};

class Condition 
{
    public:
       explicit  Condition()
        {
          pthread_cond_init(&cond_,NULL);
        }

        ~Condition()
        {
          pthread_cond_destroy(&cond_);
        }

        //Encapsulation pthread_cond_wait
        /*
        void wait()
        {
          pthread_cond_wait(&cond_, mutex_.getmutexPtr());
        }*/
                
        void wait_for(mutex& _mutex,int timeout_ms)
        {
          struct timespec abstime;
          struct timeval now;
         
          gettimeofday(&now, NULL);
          long nsec = now.tv_usec * 1000 + (timeout_ms % 1000) * 1000000;
          abstime.tv_sec=now.tv_sec + nsec / 1000000000 + timeout_ms / 1000;
          abstime.tv_nsec=nsec % 1000000000;
          pthread_cond_timedwait(&cond_, _mutex.getmutexPtr(), &abstime);
        }
        
        //Encapsulation pthread_cond_signal
        void notify()
        {
          pthread_cond_signal(&cond_);
        }
        
        //Encapsulation pthread_cond_broadcast
        void notify_all()
        {
          pthread_cond_broadcast(&cond_);
        }

    private:
        pthread_cond_t cond_;
        //mutex& mutex_;
};


#if 0
class Thread
{
  public:
    
    //typedef __thread_id id;
    typedef pthread_t native_handle_type;
    /*
    template <class F, class ...Args> explicit Thread(F& _f,Args&..._args);
    Thread()  : __t_(0U) 
    {
      //pthread_creat();
    }*/
    //template<class Function, class... Args>
    //explicit Thread(Function&& f,Args&&... args): __t_(0U);
    Thread()  : __t_(0U) 
    {
      //pthread_creat();
      ;
    }
    virtual ~Thread();

    virtual void run()=0;//virtual function

     void start()
     {
       pthread_create(&__t_,NULL,Thread::runInThread,this);
     }
    

    //void swap(thread& __t)  {_VSTD::swap(__t_, __t.__t_);}

    void join()//waits for a thread to finish its execution,Postconditions:joinable() is false
    {
      pthread_join(__t_, 0);
    } 

    void detach()//permits the thread to execute independently from the thread handle,Postconditions joinable is false
    {
      pthread_detach(__t_);
    }

    //bool joinable() const  {return !(&__t_);}
    //id get_id() const  {return (&__t_);} //return the thread id
    native_handle_type native_handle()  {return __t_;} //returns 
    //static unsigned hardware_concurrency() ; //return the numbers of concurrent threads supported by the implementation.
  private:
    pthread_t __t_;
    Thread(const Thread&);
    Thread& operator=(const Thread&);

    static void* runInThread(void *arg)
    {
      Thread *pt =static_cast<Thread*>(arg);//arg即为this指针
      pt->run();//调用run方法
      return NULL;
    }


};
#endif

#endif

//-----------------------basic command API-----------------------

int kdp_sfid_start_sync(int dev_idx, uint32_t* rsp_code, uint32_t* img_size, float thresh,
            uint16_t width, uint16_t height, uint32_t format);
int kdp_sfid_new_user_sync(int dev_idx, uint16_t usr_id, uint16_t img_idx);
int kdp_sfid_register_sync(int dev_idx, uint32_t usr_id, uint32_t* rsp_code);
int kdp_sfid_del_db_sync(int dev_idx, uint32_t usr_id, uint32_t* rsp_code);
int kdp_sfid_send_img_sync(int dev_idx, char* img_buf, int buf_len, uint32_t* rsp_code,\
        uint16_t* user_id, uint16_t* mode, bool* fd_flag, char* fd_res,\
        bool* fr_flag, char* fr_res, bool* lm_flag, char* lm_res, \
        bool* live_flag, char* live_res);
int kdp_sfid_send_img_gen(int dev_idx, char* img_buf, int buf_len, uint32_t* rsp_code,\
        uint16_t* user_id, uint16_t* mode, uint16_t* mask, char* res); 

int kdp_sfid_start_lw3d_sync(int dev_idx, uint32_t* rsp_code, uint32_t* rgb_size, \
        uint32_t* nir_size, float rgb_thresh, float nir_thresh, uint16_t rgb_width, \
        uint16_t rgb_height, uint16_t nir_width, uint16_t nir_height, \
        uint32_t rgb_fmt, uint32_t nir_fmt);

//-----------------------basic command API end----------------------- 
#endif

