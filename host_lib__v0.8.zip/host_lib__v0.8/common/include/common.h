#ifndef COMMON_H
#define COMMON_H

#define DEVICE_ID      0x520       // Kneron device id for KL520

#define FID_THRESHOLD  (0.475f)

#define MAX_USER       20  // MAX user count in DB
#define MAX_FID        5    // MAX face count for one user

#define ALL_USER_UID   0

#endif
